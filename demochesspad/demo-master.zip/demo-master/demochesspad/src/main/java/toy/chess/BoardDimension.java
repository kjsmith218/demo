package toy.chess;

public interface BoardDimension {

	public static final int Height = 4;
	public static final int Width = 3;
	public static final int Diagonal = 3;
}

package toy.move;

public enum CartesianMove {

	NONE, NORTH, SOUTH, WEST, EAST, NORTHWEST, NORTHEAST, SOUTHWEST, SOUTHEAST,

	L1, L2, L4, L5, L7, L8, L10, L11;
}
